To run the server first you need to ensure that you have node, npm and yarn installed.

Once these are installed and you are in the directory with all the files, execute "yarn install"

After this succeeds, execute ifconfig or ipconfig and note your local IP address.

After getting your IP address, execute 'yarn start'. The server should now be running.

On a machine on the same network, enter whatever you ip address is into the url bar, and append port number ':3000'

If you run this on multiple machines, you will notice all the mobile devices are in vr mode and the desktop browsers are in the classic mode for the assignment.

From here you can move things around in one window and see the effect on a different one.


Another alternative is to go to "https://hidden-beyond-21959.herokuapp.com/" and see the app hosted there.  There is only a single instance of this, so anyone on the site at the time can manipulate the arcade machine.


The joystick and camera only move in the instance where you enter commands.  Controls to move the camera are asdw qe while the crane is moved with the arrow keys, shift and space.
In VR mode, the arcade machine may start behind you, so look around.